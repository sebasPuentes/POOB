package Test;

import Maxwell.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import shapes.*;
/**
 * The test class MaxwellContainerC1Test.
 *
 * @author  (Julian Lopez , Sebastian Puentes)
 * @version (14/03/2025)
 */
public class MaxwellContainerTest
{
    private MaxwellContainer container;
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    { 
        container = new MaxwellContainer(200,300);
    }
    
    @Test
    public void shouldBeNoOk() {
    	boolean lastAction = container.ok();
    	assertEquals(false,lastAction);
    }
    
    @Test
    public void shouldBeOk() {
    	container.addDemon(0);
    	boolean lastAction = container.ok();
    	assertEquals(true,lastAction);
    }
    
    @Test
    public void shouldAddParticle(){
        container.addParticle("red",true,-150,150,15,15);
        assertTrue(container.ok());
    }
    
    @Test
    public void shouldNotDeleteParticle(){
        container.addParticle("red",true,150,150,25,25);
        container.delParticle("blue");
        assertFalse(container.ok());
    }
    
    @Test
    public void shouldDeleteParticle(){
        container.addParticle("red",true,-150,150,15,15);
        container.delParticle("red");
        assertTrue(container.ok());
    }
    
    @Test
    public void shouldAddHole(){
        container.addHole(-150,150,1);
        assertTrue(container.ok());
    }
    
    @Test
    public void shouldNotAddHole(){
        container.addHole(-400,15,1);
        assertFalse(container.ok());
    }
    
    @Test
    public void shouldAddDemon(){
        container.addDemon(15);
        assertTrue(container.ok());
    }
    
    @Test
    public void shouldNotAddParticle(){
        container.addParticle("red",true,-400,150,25,25);
        assertFalse(container.ok());
    }
    
    @Test
    public void shouldDeleteDemon(){
        container.addDemon(15);
        container.delDemon(15);
        assertTrue(container.ok());
    }
    
    @Test 
    public void shouldNotDeleteDemon(){
        container.addDemon(15);
        container.delDemon(35);
        assertFalse(container.ok()); 
    }
    
    @Test
    public void shouldMakeVisible() {
    	container.makeVisible();
    	assertTrue(container.ok());
    	
    }

    @Test
    public void shouldMakeInVisible() {
    	container.makeinVisible();
    	assertTrue(container.ok());
    }
    
    @Test
    public void shouldNotBeGoal() {
    	container.addParticles();
    	assertFalse(container.isGoal());
    	
    }
    
    @Test
    public void shouldStart() {
    	container.start(100);
    	assertTrue(container.ok());
    	
    }
    
    @Test
    public void shouldParticleBeInLeft() {
    	Normal n = new Normal("red",-100,100,10,10,true);
    	Rectangle leftBoard = container.getLeftBoard();
    	boolean isInLeft = container.isInLeftSide(n,leftBoard);
    	assertEquals(true,isInLeft);
    }
    
    @Test
    public void shouldHoleBeInLeft() {
    	Hole h = new Hole(-100,100,10,10,2);
    	Rectangle leftBoard = container.getLeftBoard();
    	boolean isInLeft = container.isInLeft(h,leftBoard);
    	assertEquals(true,isInLeft);
    }
    
    @Test
    public void shouldSortMatrixParticlesCorrectly() {
        int[][] positions = {
            {5, 1},
            {2, 2},
            {4, 3},
            {1, 4}
        };
        
        int[][] expected = {
            {1, 4},
            {2, 2},
            {4, 3},
            {5, 1}
        };
        
        container.sortMatrixParticles(positions);
        
        for (int i = 0; i < expected.length; i++) {
            assertArrayEquals(expected[i], positions[i]);
        }
    }
    
    @Test
    public void shouldReturnSortedHolePositions() {
        container.addHole(-100, 100, 1);
        container.addHole(200, 120, 1);
        container.addHole(-150, 140, 1);

        assertTrue(container.ok());

        int[][] result = container.holes();
        int[][] expected = {
            {240, 260},
            {290, 300},
            {590, 280}
        };
        
        for (int i = 0; i < expected.length; i++) {
            assertArrayEquals(expected[i], result[i]);
        }
  
    } 
    
    @Test
    public void shouldReturnSortedParticlePositions() {
        container.addParticle("red", true, -100, 150, 10, 10);
        container.addParticle("blue", false, -200, 120, 10, 10);
        container.addParticle("red", true, -150, 140, 10, 10);

        assertTrue(container.ok());

        int[][] result = container.particles();
        int[][] expected = {
            {200, 280},
            {250, 260},
            {300, 250}
        };

        for (int i = 0; i < expected.length; i++) {
            assertArrayEquals(expected[i], result[i], "Error en la posición " + i);
        }
    }

    @Test
    public void shouldReturnDemonPositions() {
        container.addDemon(100);
        container.addDemon(50);
        container.addDemon(0);

        assertTrue(container.ok());

        int[] result = container.demons();
        int[] expected = {390, 390, 390}; 

        assertArrayEquals(expected, result, "Las posiciones de los demonios no coinciden");
    }
    
    @Test
    public void shouldConvertCanvasToBoardCorrectly() {
  
        ArrayList<Integer> result = container.convertionCanvasToBoard(400, 390);

        assertEquals(2, result.size());

        assertEquals(10, result.get(0));
        assertEquals(10, result.get(1));
    }
    
    @Test
    public void shouldInitializeWithDefaultValues() {
        MaxwellContainer container = new MaxwellContainer();

   
        Rectangle left = container.getLeftBoard();
        Rectangle right = container.getRightBoard();
        Rectangle background = container.getBackgroundBoard();
        
        assertEquals(90, left.getX());
        assertEquals(200, left.getY());

        assertEquals(410, right.getX());
        assertEquals(200, right.getY());

        assertEquals(80, background.getX());
        assertEquals(180, background.getY());
    }
    
    @Test
    public void shouldInitializeWithCustomConstructor() {
    
        int d = 1;
        int b = 2;
        int r = 1;

        int[][] particles = {
            {-100, 100, 10, 10},
            {-150, 140, 20, 20},
            {-200, 120, 15, 15}
        };

        MaxwellContainer container = new MaxwellContainer(200, 300, d, b, r, particles);
        
        assertEquals(90, container.getLeftBoard().getX());
        assertEquals(200, container.getLeftBoard().getY());

        assertEquals(410, container.getRightBoard().getX());
        assertEquals(200, container.getRightBoard().getY());

        assertEquals(80, container.getBackgroundBoard().getX());
        assertEquals(180, container.getBackgroundBoard().getY());

        int[] demons = container.demons();
        assertEquals(1, demons.length);
    
        int[][] positions = container.particles(); 

        assertEquals(3, positions.length, "Debe haber 3 partículas");

        assertArrayEquals(new int[]{200, 280}, positions[0]);
        assertArrayEquals(new int[]{250, 260}, positions[1]);
        assertArrayEquals(new int[]{300, 300}, positions[2]);
    }

    @Test
    public void shouldGetHoleWidth() {
    	Hole h = new Hole(-100,100,20,20,2);
    	
    	int expectedWidth = 20;
    	
    	assertEquals(expectedWidth,h.getWidth());
    }
    
    @Test
    public void shouldGetHoleHeight() {
    	Hole h = new Hole(-100,100,20,20,2);
    	
    	int expectedHeight = 20;
    	
    	assertEquals(expectedHeight,h.getHeight());
    }
    
    @Test
    public void shouldGetHolemaxParticles() {
    	Hole h = new Hole(-100,100,20,20,2);
    	
    	int expectedParticles = 2;
    	
    	assertEquals(expectedParticles,h.getAmountParticles());
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown(){
    }

}